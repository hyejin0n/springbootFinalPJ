package com.springboot.webapp.model;

import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;

@Repository("ItemDao")
public class ItemDao {

    // DB 연결 설정
    private String jdbcURL = "jdbc:mysql://localhost:3306/springdb?characterEncoding=utf-8"; // 데이터베이스 URL
    private String jdbcUsername = "root"; // 사용자명
    private String jdbcPassword = "111111"; // 비밀번호

    // DB 연결 메서드 (필요 시 구현)
    private Connection getConn() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }

    // 상품 정보를 DB에 저장하는 메서드
    public void insertItem(ItemDo item){
        String INSERT_ITEM_SQL = "INSERT INTO items (item_name, item_price, item_status, content) VALUES (?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ITEM_SQL)) {

            preparedStatement.setString(1, item.getItem_name()); // 상품명
            preparedStatement.setInt(2, item.getItem_price());   // 가격
            preparedStatement.setString(3, item.getItem_Status()); // 상태
            preparedStatement.setString(4, item.getContent());   // 설명

            // SQL 실행
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Insert successful!");
            } else {
                System.out.println("Insert failed.");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // SQLException을 좀 더 구체적으로 출력
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // getItemList() 메서드: 상품 목록을 가져오는 메서드 (가장 최근 데이터로 정렬)
    public ArrayList<ItemDo> getItemList() {
        System.out.println("getItemList() 시작 !!");
        ArrayList<ItemDo> iList = new ArrayList<>();
        String sql = "select * from items ORDER BY created_at DESC";
        try (Connection conn = getConn(); PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                ItemDo item = new ItemDo();
                item.setSeq(rs.getInt("seq"));
                item.setItem_name(rs.getString("item_name")); // 상품명
                item.setItem_price(rs.getInt("item_price"));  // 가격
                item.setItem_Status(rs.getString("item_status")); // 상태
                item.setContent(rs.getString("content"));    // 설명
                iList.add(item);
            }
            System.out.println("getItemList() 처리 완료 !!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return iList;
    }

    // 상품 하나 가져오기
    public ItemDo getOneItem(ItemDo ido) {
        ItemDo item = new ItemDo();
        String sql = "select * from items where seq = ?";
        try (Connection conn = getConn(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, ido.getSeq());
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    item.setSeq(rs.getInt("seq"));
                    item.setItem_name(rs.getString("item_name"));
                    item.setItem_price(rs.getInt("item_price"));
                    item.setItem_Status(rs.getString("item_status"));
                    item.setContent(rs.getString("content"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return item;
    }

    // 상품 수정 메서드
    public void updateItem(ItemDo item) {
        String sql = "update items set item_name = ?, item_price = ?, item_status = ?, content = ? where seq = ?";
        try (Connection conn = getConn(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, item.getItem_name());
            pstmt.setInt(2, item.getItem_price());
            pstmt.setString(3, item.getItem_Status());
            pstmt.setString(4, item.getContent());
            pstmt.setInt(5, item.getSeq());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 상품 삭제 메서드
    public void deleteItem(ItemDo ido) {
        String sql = "delete from items where seq = ?";
        try (Connection conn = getConn(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, ido.getSeq());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


}
