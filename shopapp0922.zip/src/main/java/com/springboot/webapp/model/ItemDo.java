package com.springboot.webapp.model;

public class ItemDo {
    private int seq;
    private String item_name;
    private int item_price;
    private String item_Status;
    private String content;

    // 기본 생성자
    public ItemDo() {
    }

    // 생성자
    public ItemDo(int seq, String item_name, int item_price, String item_Status, String content) {
        this.seq = seq;
        this.item_name = item_name;
        this.item_price = item_price;
        this.item_Status = item_Status;
        this.content = content;
    }

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public int getItem_price() {
        return item_price;
    }

    public void setItem_price(int item_price) {
        this.item_price = item_price;
    }

    public String getItem_Status() {
        return item_Status;
    }

    public void setItem_Status(String item_Status) {
        this.item_Status = item_Status;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    //toString() 메서드는 객체의 메모리 참조 주소를 반환, 이를 필드값으로 출력하고 싶다면 toString()메서드를 정의해야한다.
    @Override
    public String toString(){
        return "ItemDo{" +
                "seq= " + seq + ",itemName= '" + item_name + '\'' +
                ",itemPrice= " + item_price +
                ",itemStatus='" + item_Status + '\'' +
                ",content='" + content +  '\''+
                '}';
    }
}
