package com.springboot.webapp.controller;

import java.util.ArrayList;

import com.springboot.webapp.model.*;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

//@Controller : 사용자의 요청을 처리하기 위한 클래스를 만드는
@Controller
public class BoardController {

	// 로그인 페이지 이동
	//1. login 요청이 오면 login.jsp 호출하는 메소드
	@RequestMapping(value = "/login")
	public String loginBoard(){
		System.out.println("loginBoard()처리");
		return "login";
	}

	//회원가입 페이지 이동
	//2. signup 페이지 이동
	@RequestMapping("/signup")
	public String showSignupForm() {
		return "signup";
	}

	//home 페이지 이동
	//3. home 페이지 요청 오면 home.jsp 호출
	@RequestMapping("/home")
	public String showHome(Model model){
		ItemDao itemDao = new ItemDao();
		ArrayList<ItemDo> itemList = itemDao.getItemList(); //DAO에서 상품 목록 가져오기
		model.addAttribute("itemList", itemList);
		return "home";
	}

	//회원가입 처리
	//4. signupProc.do 요청이 오면 signBoardDo 에 저장하고 해당 데이터를 DB에 저장
	// DB table = smember
	@Autowired
	private SignupDao signupDao;
	@PostMapping(value = "signupProc.do")
	public String signupProc(SignupDo sbdo){
		System.out.println("signupProc()처리");

		//Singup 객체에 저장되어 있는지 확인하는 출력문
		System.out.println("email: " + sbdo.getEmail());
		System.out.println("userName: " + sbdo.getUserName());
		System.out.println("password: " + sbdo.getPassWord());

		signupDao.insertSignup(sbdo);

		return "redirect:login";
	}

	//메인화면
	//5.login화면에서 요청이 들어오면 home페이지로 이동하는 컨트롤러
	@RequestMapping("/loginProcBoard")
	public String loginProcBoard(){
		//이메일과 비밀번호 처리 로직
		System.out.println("loginProcBoard()성공!");
		//로그인 성공 or 실패 처리 후 페이지 이동
		return "home";
	}

	//6.home 화면에서 itemList 요청이 들어오면 페이지 이동 (수정완)
	@RequestMapping(value = "/itemList")
	public ModelAndView itemList(ItemDao idao, ModelAndView imav) {
		//전체 데이터를 디비에서 읽어오는 처리 후에 뷰어 호출
		ArrayList<ItemDo> iList = idao.getItemList();
		if (iList.isEmpty()){
			System.out.println("No items found in the Database.");
		}else {
			for (ItemDo ido : iList) {
				System.out.println("-->" + ido.toString());
			}
		}
		imav.addObject("iList", iList);
		imav.setViewName("itemList");
		return imav;
	}

	//7.itemList 화면에서 insertItem 요청이 들어오면 페이지 이동
	@RequestMapping(value = "/insertItem")
	public String insertItemBoard() {
		System.out.println("insertItemBoard()처리");
		return "insertItem";
	}

	//8.insertItem에서 insertProcItem요청이 들어오면 해당 데이터 디비에 저장 후 itemList.jsp호출
	@RequestMapping(value = "insertProcItem", method = RequestMethod.POST)
	public String insertProcItem(ItemDo ido) {
		System.out.println("insertProcItem()처리");
		System.out.println("item_name: " + ido.getItem_name());
		System.out.println("item_price: " + ido.getItem_price());
		System.out.println("item_status: " + ido.getItem_Status());
		System.out.println("item_content: " + ido.getContent());

		//Dao 이용하여 디비에 입력된 값을 저장
		ItemDao idao = new ItemDao();
		idao.insertItem(ido);
		System.out.println("Dao 이용해 데이터 DB저장 완료");

		return "redirect:itemList";

	}

	//9. 상품 수정 페이지 이동
	@RequestMapping(value = "/modifyItem")
	public ModelAndView modifyItem(ItemDao idao, ItemDo ido, ModelAndView imav ){
		System.out.println("modifyItem()처리");

		ItemDo item = idao.getOneItem(ido);
		imav.addObject("item",item);
		imav.setViewName("modifyItem");
		return imav;
	}

	//10. 상품 수정 처리
	@PostMapping(value = "/modifyProcItem")
	public String modifyProcItem(ItemDo ido, ItemDao idao){
		System.out.println("modifyProcItem()처리");
		idao.updateItem(ido);
		System.out.println("데이터 수정 저장 완료");
		return "redirect:itemList";
	}

	//11. 상품 삭제 처리
	@RequestMapping(value = "/deleteItem")
	public String deleteItem(ItemDo ido, ItemDao idao){
		idao.deleteItem(ido);
		return "redirect:itemList";
	}

	

}
