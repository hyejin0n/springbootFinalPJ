package com.springboot.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Webapp5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
